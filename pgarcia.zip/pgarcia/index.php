<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pol</title>

    <link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_url' ); ?>" />

</head>
<body>
    <h1>POL GARCIA</h1>
   <?php
    if (have_posts()) :
        while (have_posts()) :
            the_post();
            ?>
            <h2><?php the_title(); ?></h2>
            <div><?php the_content(); ?></div>
            <?php
        endwhile; // end while
    else :
        echo '<p>No posts found.</p>';
    endif; // end if
    ?>
</body>
</html>